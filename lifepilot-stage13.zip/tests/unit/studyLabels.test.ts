import { describe, it } from 'node:test';
import assert from 'node:assert/strict';
import { INITIAL_SRS_STATE, intervalCap } from '../../src/features/study/services/srs';
import { formatInterval, previewIntervals } from '../../src/features/study/services/studyLabels';

describe('interval labels', () => {
  it('writes intervals in Persian', () => {
    assert.equal(formatInterval(1), 'فردا');
    assert.equal(formatInterval(3), '۳ روز دیگر');
    assert.equal(formatInterval(13), '۱۳ روز دیگر');
    assert.equal(formatInterval(14), 'حدود ۲ هفته دیگر');
    assert.equal(formatInterval(45), 'حدود ۶ هفته دیگر');
    assert.equal(formatInterval(60), 'حدود ۲ ماه دیگر');
    assert.equal(formatInterval(180), 'حدود ۶ ماه دیگر');
  });

  it('previews what each answer schedules', () => {
    assert.deepEqual(previewIntervals(INITIAL_SRS_STATE, 180), { 0: 'فردا', 1: 'فردا', 2: '۳ روز دیگر', 3: '۵ روز دیگر' });
  });

  it('previews respect the exam limit', () => {
    const p = previewIntervals({ intervalDays: 10, ease: 2.5, repetitions: 3, lapses: 0 }, 5);
    assert.equal(p[2], '۵ روز دیگر');
    assert.equal(p[3], '۵ روز دیگر');
  });
});

describe('interval cap from the exam date', () => {
  const now = new Date(2026, 10, 5, 12).getTime();
  it('has no cap without an exam, and a smaller one close to it', () => {
    assert.equal(intervalCap(null, now), 180);
    assert.equal(intervalCap(new Date(2027, 1, 3).getTime(), now), 30); // 90 days away
    assert.equal(intervalCap(new Date(2026, 10, 20).getTime(), now), 5);
    assert.equal(intervalCap(new Date(2026, 10, 1).getTime(), now), 1); // exam already passed
  });
});
