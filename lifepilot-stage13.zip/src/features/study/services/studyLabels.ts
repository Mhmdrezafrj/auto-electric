import { toPersianDigits } from '../../../core/calendar/format';
import { RATINGS, Rating, SrsState, nextState } from './srs';

/** "فردا", "۳ روز دیگر", "حدود ۲ هفته دیگر", "حدود ۲ ماه دیگر" */
export function formatInterval(days: number): string {
  if (days <= 1) return 'فردا';
  if (days < 14) return `${toPersianDigits(days)} روز دیگر`;
  if (days < 60) return `حدود ${toPersianDigits(Math.round(days / 7))} هفته دیگر`;
  return `حدود ${toPersianDigits(Math.round(days / 30))} ماه دیگر`;
}

/** What each answer would schedule, so the student sees the effect before choosing. */
export function previewIntervals(state: SrsState, cap: number): Record<Rating, string> {
  const out = {} as Record<Rating, string>;
  for (const r of RATINGS) out[r] = formatInterval(nextState(state, r, cap).intervalDays);
  return out;
}
