import { localDayNumber } from '../../../core/calendar/dates';

/**
 * Spaced repetition with self-testing (active recall), in the style of SM-2/Anki:
 * after each review the student says how well they remembered, and the gap to the next review
 * grows when it was easy and resets when it was forgotten. The very first review is 1 day after learning.
 * Everything here is a pure function.
 */
export type Rating = 0 | 1 | 2 | 3;
export const RATINGS: Rating[] = [0, 1, 2, 3];
export const RATING_LABELS: Record<Rating, string> = {
  0: 'فراموش کردم',
  1: 'سخت بود',
  2: 'خوب بود',
  3: 'آسان بود',
};

export interface SrsState {
  /** Days until the next review. */
  intervalDays: number;
  /** How fast the gap grows (1.3 .. 3.0). */
  ease: number;
  /** Successful reviews in a row (reset to 0 when forgotten). */
  repetitions: number;
  /** Times the topic was forgotten. */
  lapses: number;
}

export const INITIAL_SRS_STATE: SrsState = { intervalDays: 1, ease: 2.5, repetitions: 0, lapses: 0 };

export const MIN_EASE = 1.3;
export const MAX_EASE = 3.0;
export const DEFAULT_MAX_INTERVAL_DAYS = 180;

const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));
const round2 = (v: number) => Math.round(v * 100) / 100;

/** Whole days from `now` until the exam day (0 on exam day, negative after). */
export function daysUntil(examAt: number, now: number): number {
  return localDayNumber(new Date(examAt)) - localDayNumber(new Date(now));
}

/**
 * Longest gap allowed so that a topic is still reviewed about 3 more times before the exam.
 * No exam date means the normal maximum.
 */
export function examMaxInterval(daysLeft: number | null): number {
  if (daysLeft === null) return DEFAULT_MAX_INTERVAL_DAYS;
  return clamp(Math.floor(daysLeft / 3), 1, DEFAULT_MAX_INTERVAL_DAYS);
}

/** The longest gap allowed today, given the exam date (or none). */
export function intervalCap(examAt: number | null, now: number): number {
  return examMaxInterval(examAt === null ? null : Math.max(0, daysUntil(examAt, now)));
}

export function nextState(state: SrsState, rating: Rating, maxIntervalDays = DEFAULT_MAX_INTERVAL_DAYS): SrsState {
  const cap = Math.max(1, Math.floor(maxIntervalDays));
  const reps = state.repetitions;

  if (rating === 0) {
    return { intervalDays: 1, ease: round2(clamp(state.ease - 0.2, MIN_EASE, MAX_EASE)), repetitions: 0, lapses: state.lapses + 1 };
  }

  let interval: number;
  let ease = state.ease;
  if (rating === 1) {
    interval = Math.max(state.intervalDays, Math.round(state.intervalDays * 1.2));
    ease = state.ease - 0.15;
  } else if (rating === 2) {
    interval = reps === 0 ? 3 : reps === 1 ? 7 : Math.round(state.intervalDays * state.ease);
  } else {
    interval = reps === 0 ? 5 : reps === 1 ? 10 : Math.round(state.intervalDays * state.ease * 1.3);
    ease = state.ease + 0.15;
  }

  return {
    intervalDays: clamp(interval, 1, cap),
    ease: round2(clamp(ease, MIN_EASE, MAX_EASE)),
    repetitions: reps + 1,
    lapses: state.lapses,
  };
}
