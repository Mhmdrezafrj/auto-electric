import { useEffect, useMemo, useState } from 'react';
import { useRepositories, useServices } from '@/providers/DatabaseProvider';
import { useNow } from '@/shared/hooks/useNow';
import { useDataStore } from '@/shared/state/dataStore';
import type { StudyMaterial, StudySubject, StudyTopic } from '../models/study';
import { dueTopics, forecast, interleave, sortByUrgency } from '../services/reviewQueue';

interface State {
  subjects: StudySubject[];
  materials: StudyMaterial[];
  topics: StudyTopic[];
  exam: number | null;
  loading: boolean;
}

/** Everything the study screens show, loaded from the database and refreshed after every change. */
export function useStudyData() {
  const repos = useRepositories();
  const services = useServices();
  const version = useDataStore((s) => s.version);
  const now = useNow();
  const [state, setState] = useState<State>({ subjects: [], materials: [], topics: [], exam: null, loading: true });

  useEffect(() => {
    let cancelled = false;
    Promise.all([
      repos.study.listSubjects(),
      repos.study.listMaterials(),
      repos.study.listTopics(),
      services.study.getExamDate(),
    ])
      .then(([subjects, materials, topics, exam]) => {
        if (!cancelled) setState({ subjects, materials, topics, exam, loading: false });
      })
      .catch(() => {
        if (!cancelled) setState((s) => ({ ...s, loading: false }));
      });
    return () => {
      cancelled = true;
    };
  }, [repos, services, version]);

  const queue = useMemo(
    () => interleave(sortByUrgency(dueTopics(state.topics, now), now)),
    [state.topics, now],
  );
  const upcoming = useMemo(() => forecast(state.topics, now, 7), [state.topics, now]);

  return { ...state, now, queue, upcoming };
}
