import { useMemo } from 'react';
import { useRepositories, useServices } from '@/providers/DatabaseProvider';
import { useDataStore } from '@/shared/state/dataStore';

/** Study changes; every successful or failed call refreshes the study screens. */
export function useStudyActions() {
  const repos = useRepositories();
  const services = useServices();
  const bump = useDataStore((s) => s.bump);

  return useMemo(() => {
    const wrap =
      <A extends unknown[], R>(fn: (...a: A) => Promise<R>) =>
      async (...a: A): Promise<R> => {
        try {
          return await fn(...a);
        } finally {
          bump();
        }
      };
    return {
      addMaterial: wrap(services.study.addMaterial),
      addSubject: wrap(services.study.addSubject),
      addLearned: wrap(services.study.addLearned),
      review: wrap(services.study.review),
      deleteMaterial: wrap((id: string) => repos.study.deleteMaterial(id)),
      deleteSubject: wrap((id: string) => repos.study.deleteSubject(id)),
      deleteTopic: wrap((id: string) => repos.study.deleteTopic(id)),
      setSuspended: wrap((id: string, suspended: boolean) => repos.study.setSuspended(id, suspended)),
    };
  }, [repos, services, bump]);
}
