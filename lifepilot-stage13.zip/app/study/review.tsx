import { useEffect, useState } from 'react';
import { Alert, Pressable, View } from 'react-native';
import { useRouter } from 'expo-router';
import { formatDayLabel, toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { MATERIAL_KIND_LABELS } from '@/features/study/models/study';
import { useStudyActions } from '@/features/study/hooks/useStudyActions';
import { useStudyData } from '@/features/study/hooks/useStudyData';
import { RATINGS, RATING_LABELS, Rating, intervalCap } from '@/features/study/services/srs';
import { previewIntervals } from '@/features/study/services/studyLabels';
import { AppText } from '@/shared/components/AppText';
import { Badge } from '@/shared/components/Badge';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Screen } from '@/shared/components/Screen';

export default function ReviewScreen() {
  const router = useRouter();
  const { colors, spacing, radii } = useTheme();
  const { queue, topics, exam, now, loading } = useStudyData();
  const actions = useStudyActions();
  const [ids, setIds] = useState<string[] | null>(null); // frozen at the start so the order does not change while reviewing
  const [index, setIndex] = useState(0);
  const [saving, setSaving] = useState(false);
  const [done, setDone] = useState<number[]>([0, 0, 0, 0]);

  useEffect(() => {
    if (ids === null && !loading) setIds(queue.map((t) => t.id));
  }, [ids, loading, queue]);

  const total = ids?.length ?? 0;
  const topic = ids && index < ids.length ? topics.find((t) => t.id === ids[index]) : undefined;
  const finished = ids !== null && (index >= total || total === 0);

  const rate = async (r: Rating) => {
    if (!topic || saving) return;
    setSaving(true);
    try {
      await actions.review(topic.id, r);
      setDone((d) => d.map((n, i) => (i === r ? n + 1 : n)));
      setIndex((i) => i + 1);
    } catch (e) {
      Alert.alert('خطا', describeError(e));
    } finally {
      setSaving(false);
    }
  };

  if (ids === null) return <Screen title="مرور امروز" onBack={() => router.back()}><AppText muted>در حال آماده‌سازی…</AppText></Screen>;

  if (finished) {
    const count = done.reduce((a, b) => a + b, 0);
    return (
      <Screen title="مرور امروز" onBack={() => router.back()}>
        <Card>
          <AppText variant="heading">{count > 0 ? 'آفرین! مرور امروز تمام شد 🎉' : 'امروز مرور باقی نمانده است'}</AppText>
          {count > 0 ? (
            <AppText muted>
              {toPersianDigits(count)} مبحث مرور شد: {toPersianDigits(done[3])} آسان، {toPersianDigits(done[2])} خوب،{' '}
              {toPersianDigits(done[1])} سخت، {toPersianDigits(done[0])} فراموش‌شده. مباحث فراموش‌شده فردا دوباره می‌آیند.
            </AppText>
          ) : null}
          <Button title="بازگشت" onPress={() => router.back()} />
        </Card>
      </Screen>
    );
  }

  if (!topic) return <Screen title="مرور امروز" onBack={() => router.back()}><AppText muted>این مبحث پیدا نشد.</AppText></Screen>;

  const preview = previewIntervals(
    { intervalDays: topic.intervalDays, ease: topic.ease, repetitions: topic.repetitions, lapses: topic.lapses },
    intervalCap(exam, now),
  );
  const tone: Record<Rating, string> = { 0: colors.danger, 1: colors.warning, 2: colors.accent, 3: colors.success };

  return (
    <Screen title="مرور امروز" subtitle={`${toPersianDigits(index + 1)} از ${toPersianDigits(total)}`} onBack={() => router.back()}>
      <Card>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          {topic.subjectName ? <Badge label={topic.subjectName} color={topic.subjectColor ?? undefined} /> : null}
          <Badge label={`${MATERIAL_KIND_LABELS[topic.materialKind]}: ${topic.materialTitle}`} color={colors.textMuted} />
          {topic.lapses > 0 ? <Badge label={`${toPersianDigits(topic.lapses)} بار فراموش‌شده`} color={colors.danger} /> : null}
        </View>
        <AppText variant="title">{topic.title}</AppText>
        <AppText muted>
          بدون نگاه‌کردن به کتاب یا جزوه، هرچه از این مبحث یادت است بگو یا بنویس. بعد صادقانه بگو چقدر خوب بود.
        </AppText>
        <AppText variant="caption" muted>
          یاد گرفته‌شده: {formatDayLabel(new Date(topic.learnedAt), new Date(now))}
        </AppText>
      </Card>

      <AppText variant="label" muted>چقدر خوب یادت بود؟ (مرور بعدی را همین تعیین می‌کند)</AppText>
      <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
        {RATINGS.map((r) => (
          <Pressable
            key={r}
            accessibilityRole="button"
            accessibilityLabel={`${RATING_LABELS[r]}، ${preview[r]}`}
            disabled={saving}
            onPress={() => void rate(r)}
            style={({ pressed }) => ({
              width: '48%',
              minHeight: 84,
              borderRadius: radii.lg,
              padding: spacing.md,
              justifyContent: 'center',
              gap: 4,
              backgroundColor: colors.surface,
              borderWidth: 2,
              borderColor: tone[r],
              opacity: saving ? 0.5 : pressed ? 0.8 : 1,
            })}
          >
            <AppText variant="bodyStrong" style={{ color: tone[r] }}>{RATING_LABELS[r]}</AppText>
            <AppText variant="caption" muted>مرور بعدی: {preview[r]}</AppText>
          </Pressable>
        ))}
      </View>
    </Screen>
  );
}
