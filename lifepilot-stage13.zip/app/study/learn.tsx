import { useState } from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { categoryPalette } from '@/core/theme/colors';
import { useTheme } from '@/core/theme/useTheme';
import { MATERIAL_KINDS, MATERIAL_KIND_LABELS, MaterialKind } from '@/features/study/models/study';
import { useStudyActions } from '@/features/study/hooks/useStudyActions';
import { useStudyData } from '@/features/study/hooks/useStudyData';
import { parseTopicList } from '@/features/study/services/reviewQueue';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Chip } from '@/shared/components/Chip';
import { Screen } from '@/shared/components/Screen';
import { TextField } from '@/shared/components/TextField';

export default function LearnScreen() {
  const router = useRouter();
  const { spacing } = useTheme();
  const { materials, subjects, loading } = useStudyData();
  const actions = useStudyActions();
  const [materialId, setMaterialId] = useState<string | null>(null);
  const [creating, setCreating] = useState(false);
  const [title, setTitle] = useState('');
  const [kind, setKind] = useState<MaterialKind>('book');
  const [subjectId, setSubjectId] = useState<string | null>(null);
  const [newSubject, setNewSubject] = useState('');
  const [text, setText] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);

  const showForm = creating || (!loading && materials.length === 0);
  const topicCount = parseTopicList(text).length;

  const createMaterial = async () => {
    setError(null);
    try {
      let sid = subjectId;
      if (newSubject.trim()) {
        const s = await actions.addSubject({ name: newSubject, color: categoryPalette[subjects.length % categoryPalette.length] });
        sid = s.id;
      }
      const m = await actions.addMaterial({ subjectId: sid, kind, title });
      setMaterialId(m.id);
      setCreating(false);
      setTitle('');
      setNewSubject('');
    } catch (e) {
      setError(describeError(e));
    }
  };

  const save = async () => {
    if (!materialId) {
      setError('ابتدا منبع را انتخاب یا بسازید');
      return;
    }
    setSaving(true);
    setError(null);
    try {
      await actions.addLearned(materialId, text);
      router.back();
    } catch (e) {
      setError(describeError(e));
      setSaving(false);
    }
  };

  return (
    <Screen title="ثبت چیزی که یاد گرفتم" subtitle="اولین مرور فردا خواهد بود" onBack={() => router.back()}>
      <View style={{ gap: spacing.sm }}>
        <AppText variant="label" muted>منبع (کتاب یا فیلم آموزشی)</AppText>
        <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
          {materials.map((m) => (
            <Chip key={m.id} label={m.title} selected={materialId === m.id} onPress={() => setMaterialId(m.id)} />
          ))}
          <Chip icon="add" label="منبع جدید" selected={showForm} onPress={() => setCreating(true)} />
        </View>
      </View>

      {showForm ? (
        <Card variant="outlined" style={{ gap: spacing.md }}>
          <TextField label="عنوان منبع" placeholder="مثلاً: ریاضی ۳ - گاج، یا فیلم فیزیک - حرکت" value={title} onChangeText={setTitle} maxLength={120} />
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            {MATERIAL_KINDS.map((k) => (
              <Chip key={k} label={MATERIAL_KIND_LABELS[k]} selected={kind === k} onPress={() => setKind(k)} />
            ))}
          </View>
          <AppText variant="label" muted>درس (اختیاری)</AppText>
          <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: spacing.sm }}>
            {subjects.map((s) => (
              <Chip key={s.id} label={s.name} color={s.color} selected={subjectId === s.id && !newSubject.trim()} onPress={() => { setSubjectId(s.id); setNewSubject(''); }} />
            ))}
          </View>
          <TextField placeholder={subjects.length ? 'یا درس جدید…' : 'نام درس، مثلاً: ریاضی'} value={newSubject} onChangeText={setNewSubject} maxLength={40} />
          <Button title="ساخت منبع" size="sm" variant="secondary" onPress={() => void createMaterial()} />
        </Card>
      ) : null}

      <TextField
        label="مباحثی که یاد گرفتم"
        placeholder={'هر مبحث در یک خط، مثلاً:\nحد و پیوستگی\nمشتق\nکاربرد مشتق'}
        value={text}
        onChangeText={setText}
        multiline
      />
      <AppText variant="caption" muted>
        {topicCount > 0 ? `${toPersianDigits(topicCount)} مبحث ثبت می‌شود.` : 'مباحث را با خط جدید یا ویرگول جدا کنید.'}
      </AppText>

      {error ? <AppText color="danger">{error}</AppText> : null}
      <Button title="ثبت مباحث" size="lg" fullWidth loading={saving} disabled={topicCount === 0} onPress={() => void save()} />
    </Screen>
  );
}
