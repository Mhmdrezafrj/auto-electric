import { Alert, View } from 'react-native';
import { useRouter } from 'expo-router';
import { toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { MATERIAL_KIND_LABELS, StudyMaterial } from '@/features/study/models/study';
import { useStudyActions } from '@/features/study/hooks/useStudyActions';
import { useStudyData } from '@/features/study/hooks/useStudyData';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { IconButton } from '@/shared/components/IconButton';
import { Screen } from '@/shared/components/Screen';

export default function MaterialsScreen() {
  const router = useRouter();
  const { colors, spacing } = useTheme();
  const { subjects, materials, loading } = useStudyData();
  const actions = useStudyActions();

  const groups: { id: string | null; name: string; color: string | null; items: StudyMaterial[] }[] = [
    ...subjects.map((s) => ({ id: s.id, name: s.name, color: s.color, items: materials.filter((m) => m.subjectId === s.id) })),
    { id: null, name: 'بدون درس', color: null, items: materials.filter((m) => m.subjectId === null) },
  ].filter((g) => g.items.length > 0 || g.id !== null);

  const removeSubject = (id: string, name: string) =>
    Alert.alert('حذف درس', `درس «${name}» حذف شود؟ منابع و مباحث آن می‌مانند و فقط بدون درس می‌شوند.`, [
      { text: 'انصراف', style: 'cancel' },
      { text: 'حذف', style: 'destructive', onPress: () => actions.deleteSubject(id).catch((e) => Alert.alert('خطا', describeError(e))) },
    ]);

  return (
    <Screen title="منابع و مباحث من" onBack={() => router.back()}>
      <Button title="ثبت چیزی که یاد گرفتم" icon="add" onPress={() => router.push('/study/learn')} />
      {!loading && materials.length === 0 && subjects.length === 0 ? <AppText muted>هنوز منبعی ثبت نشده است.</AppText> : null}

      {groups.map((g) => (
        <View key={g.id ?? 'none'} style={{ gap: spacing.sm }}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
            <View style={{ width: 12, height: 12, borderRadius: 6, backgroundColor: g.color ?? colors.textMuted }} />
            <View style={{ flex: 1 }}><AppText variant="bodyStrong">{g.name}</AppText></View>
            {g.id ? (
              <IconButton icon="trash-outline" color={colors.danger} accessibilityLabel="حذف درس" onPress={() => removeSubject(g.id as string, g.name)} />
            ) : null}
          </View>
          {g.items.length === 0 ? <AppText variant="caption" muted>منبعی برای این درس نیست.</AppText> : null}
          {g.items.map((m) => (
            <Card key={m.id} variant="outlined" onPress={() => router.push(`/study/material/${m.id}`)} accessibilityLabel={m.title}>
              <AppText variant="bodyStrong">{m.title}</AppText>
              <AppText variant="caption" muted>
                {MATERIAL_KIND_LABELS[m.kind]} · {toPersianDigits(m.topicCount)} مبحث
              </AppText>
            </Card>
          ))}
        </View>
      ))}
    </Screen>
  );
}
