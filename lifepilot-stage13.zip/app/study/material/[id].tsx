import { Alert, View } from 'react-native';
import { useLocalSearchParams, useRouter } from 'expo-router';
import { formatDayLabel, toPersianDigits } from '@/core/calendar/format';
import { describeError } from '@/core/errors';
import { useTheme } from '@/core/theme/useTheme';
import { MATERIAL_KIND_LABELS } from '@/features/study/models/study';
import { useStudyActions } from '@/features/study/hooks/useStudyActions';
import { useStudyData } from '@/features/study/hooks/useStudyData';
import { AppText } from '@/shared/components/AppText';
import { Button } from '@/shared/components/Button';
import { Card } from '@/shared/components/Card';
import { Chip } from '@/shared/components/Chip';
import { IconButton } from '@/shared/components/IconButton';
import { Screen } from '@/shared/components/Screen';

export default function MaterialDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { colors, spacing } = useTheme();
  const { materials, topics, now, loading } = useStudyData();
  const actions = useStudyActions();
  const material = materials.find((m) => m.id === id);
  const list = topics.filter((t) => t.materialId === id);
  const fail = (e: unknown) => Alert.alert('خطا', describeError(e));

  if (!material) {
    return (
      <Screen title="منبع" onBack={() => router.back()}>
        <AppText muted>{loading ? 'در حال بارگذاری…' : 'این منبع پیدا نشد (ممکن است حذف شده باشد).'}</AppText>
      </Screen>
    );
  }

  const removeMaterial = () =>
    Alert.alert('حذف منبع', `«${material.title}» با همه‌ی مباحث و تاریخچه‌ی مرورش حذف شود؟`, [
      { text: 'انصراف', style: 'cancel' },
      {
        text: 'حذف',
        style: 'destructive',
        onPress: () => actions.deleteMaterial(material.id).then(() => router.back()).catch(fail),
      },
    ]);

  return (
    <Screen title={material.title} subtitle={`${MATERIAL_KIND_LABELS[material.kind]} · ${toPersianDigits(list.length)} مبحث`} onBack={() => router.back()}>
      {list.map((t) => (
        <Card key={t.id} variant="outlined">
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: spacing.sm }}>
            <View style={{ flex: 1, gap: 2 }}>
              <AppText variant="bodyStrong" muted={t.suspended}>{t.title}</AppText>
              <AppText variant="caption" muted>
                {t.suspended ? 'متوقف‌شده' : `مرور بعدی: ${formatDayLabel(new Date(t.dueAt), new Date(now))}`}
                {t.repetitions > 0 ? ` · ${toPersianDigits(t.repetitions)} مرور موفق` : ''}
                {t.lapses > 0 ? ` · ${toPersianDigits(t.lapses)} فراموشی` : ''}
              </AppText>
            </View>
            <Chip
              label={t.suspended ? 'ادامه' : 'توقف'}
              onPress={() => actions.setSuspended(t.id, !t.suspended).catch(fail)}
            />
            <IconButton
              icon="trash-outline"
              color={colors.danger}
              accessibilityLabel="حذف مبحث"
              onPress={() =>
                Alert.alert('حذف مبحث', `«${t.title}» حذف شود؟`, [
                  { text: 'انصراف', style: 'cancel' },
                  { text: 'حذف', style: 'destructive', onPress: () => actions.deleteTopic(t.id).catch(fail) },
                ])
              }
            />
          </View>
        </Card>
      ))}
      {list.length === 0 ? <AppText muted>مبحثی ثبت نشده است.</AppText> : null}
      <Button title="حذف این منبع" variant="ghost" icon="trash-outline" onPress={removeMaterial} />
    </Screen>
  );
}
